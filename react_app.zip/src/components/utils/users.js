const users = [
  {
    id: 1,
    email: "admin@example.com",
    password: "admin123",
    role: "admin",
  },
  {
    id: 2,
    email: "user1@example.com",
    password: "user123",
    role: "user",
  },
  {
    id: 3,
    email: "user2@example.com",
    password: "test456",
    role: "user",
  },
];

export default users;
